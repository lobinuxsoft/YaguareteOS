"""sysfs/procfs reads for the AMD APU firmware UMA carveout.

Ported from YaguareteOS's Decky plugin (system_files/usr/share/yaguarete/decky/
YaguareteVram/main.py in yaguarete_os) -- that plugin superseded an earlier
hhd-vram that tuned GTT via ttm.pages_limit. The carveout knob below is
simpler and more correct: it asks the firmware to move its actual VRAM
carveout, validated by the kernel, instead of competing with it via GTT.
"""

import glob
import os
import re

_OPTION_PAT = re.compile(r"^\s*(\d+)\s*:\s*(.*?)\s*\(([^)]*)\)\s*$")


def read_int(path: str) -> int:
    with open(path) as f:
        return int(f.read().strip())


def find_amdgpu_device() -> str | None:
    """sysfs device path of an AMD GPU exposing the firmware carveout, or None."""
    fallback = None
    for dev in sorted(glob.glob("/sys/class/drm/card*/device")):
        if not os.path.exists(os.path.join(dev, "uma", "carveout")):
            continue
        if fallback is None:
            fallback = dev
        try:
            with open(os.path.join(dev, "uevent")) as f:
                if "DRIVER=amdgpu" in f.read():
                    return dev
        except OSError:
            continue
    return fallback


def uma_dir(device: str) -> str:
    return os.path.join(device, "uma")


def _option_mib(size: str) -> int | None:
    """'512 MB' -> 512, '8 GB' -> 8192. Unparseable -> None."""
    m = re.search(r"\d+", size)
    if not m:
        return None
    n = int(m.group())
    return n if "m" in size.lower() else n * 1024


def uma_options(device: str) -> list[dict]:
    """The carveout sizes the firmware accepts, in the order it lists them."""
    options = []
    with open(os.path.join(uma_dir(device), "carveout_options")) as f:
        for line in f:
            m = _OPTION_PAT.match(line)
            if not m:
                continue
            index, word, size = int(m.group(1)), m.group(2), m.group(3)
            mib = _option_mib(size)
            if mib is None:
                continue
            options.append(
                {"index": index, "mib": mib, "label": f"{size} ({word})" if word else size}
            )
    return options


def read_vram_total(device: str) -> int:
    path = os.path.join(device, "mem_info_vram_total")
    return read_int(path) if os.path.exists(path) else 0


def ram_bytes() -> int:
    with open("/proc/meminfo") as f:
        for line in f:
            if line.startswith("MemTotal:"):
                return int(line.split()[1]) * 1024
    raise RuntimeError("MemTotal missing from /proc/meminfo")


def bytes_to_gib(n: int) -> float:
    return n / (1024**3)
