"""sysfs reads for the AMD APU firmware UMA carveout.

Ported from YaguareteOS's Decky plugin (system_files/usr/share/yaguarete/decky/
YaguareteVram/main.py in yaguarete_os) -- that plugin superseded an earlier
hhd-vram that tuned GTT via ttm.pages_limit. The carveout knob below is
simpler and more correct: it asks the firmware to move its actual VRAM
carveout, validated by the kernel, instead of competing with it via GTT.
"""

import glob
import os
import re

_OPTION_PAT = re.compile(r"^\s*(\d+)\s*:\s*(.*?)\s*\(([^)]*)\)\s*$")


def read_int(path: str) -> int:
    with open(path) as f:
        return int(f.read().strip())


def find_amdgpu_device() -> str | None:
    """sysfs device path of an AMD GPU exposing the firmware carveout, or None."""
    fallback = None
    for dev in sorted(glob.glob("/sys/class/drm/card*/device")):
        if not os.path.exists(os.path.join(dev, "uma", "carveout")):
            continue
        if fallback is None:
            fallback = dev
        try:
            with open(os.path.join(dev, "uevent")) as f:
                if "DRIVER=amdgpu" in f.read():
                    return dev
        except OSError:
            continue
    return fallback


def uma_dir(device: str) -> str:
    return os.path.join(device, "uma")


def uma_options(device: str) -> list[dict]:
    """The carveout sizes the firmware accepts, in the order it lists them.

    `index` is the firmware's own slot number -- what the slider shows as a
    tick and what `carveout` is written back as. The raw MiB size is never
    shown on the slider itself: with up to 7 options up to 5 digits long
    (512..32768), the UI's tick labels overlap. `label` carries the real
    size for the status text instead.
    """
    options = []
    with open(os.path.join(uma_dir(device), "carveout_options")) as f:
        for line in f:
            m = _OPTION_PAT.match(line)
            if not m:
                continue
            index, word, size = int(m.group(1)), m.group(2), m.group(3)
            options.append({"index": index, "label": f"{size} ({word})" if word else size})
    return options
