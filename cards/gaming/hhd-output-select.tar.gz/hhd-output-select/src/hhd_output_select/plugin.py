"""Output-select plugin: picks the monitor Gamemode's Gamescope uses.

Gamescope only reads `--prefer-output` at startup, so there is no live
hot-switch -- applying a new choice writes the config file Gamescope's
launcher reads, then ends the current graphical session so the display
manager starts a fresh one with it applied.
"""

import logging
import subprocess

from hhd.plugins import Context, HHDPlugin, HHDSettings, load_relative_yaml
from hhd.plugins.conf import Config

from .outputs import connected_outputs

logger = logging.getLogger(__name__)

CONFIG_PATH = "/etc/yaguarete/gamescope-preferred-output"

# UI config paths (section.container.field). "output" is our own top-level
# section, separate from "vram"/"ssh" since this feature shares nothing
# with those.
ROOT = "output.monitor"


def _current_choice() -> str | None:
    try:
        with open(CONFIG_PATH) as f:
            value = f.read().strip()
            return value or None
    except OSError:
        return None


def _active_session_id() -> str | None:
    """Session id of the graphical session on seat0, or None if not found."""
    try:
        out = subprocess.run(
            ["loginctl", "list-sessions", "--no-legend"],
            capture_output=True, text=True, check=True,
        ).stdout
    except (OSError, subprocess.CalledProcessError) as err:
        logger.error("loginctl list-sessions failed: %s", err)
        return None

    for line in out.splitlines():
        fields = line.split()
        if len(fields) >= 4 and fields[3] == "seat0":
            return fields[0]
    return None


class OutputSelectPlugin(HHDPlugin):
    def __init__(self) -> None:
        self.name = "hhd_output_select"
        self.priority = 60
        self.log = "outsel"
        self.emit = None

    def open(self, emit, context: Context) -> None:
        self.emit = emit

    def settings(self) -> HHDSettings:
        sets = load_relative_yaml("settings.yml")
        outputs = connected_outputs()
        sets["children"]["choice"]["options"] = {o: o for o in outputs}
        sets["children"]["choice"]["default"] = _current_choice() or outputs[0]
        return {"output": {"monitor": sets}}

    def update(self, conf: Config) -> None:
        current = _current_choice()
        selected = conf.get(f"{ROOT}.choice", None)

        if selected is None:
            conf[f"{ROOT}.status"] = "Sin seleccion."
        elif selected == current:
            conf[f"{ROOT}.status"] = f"Actual: {selected}"
        else:
            conf[f"{ROOT}.status"] = f"Vas a usar: {selected}"

        if not conf.get_action(f"{ROOT}.apply") or not selected:
            return
        if selected == current:
            return

        try:
            import os
            os.makedirs("/etc/yaguarete", exist_ok=True)
            with open(CONFIG_PATH, "w") as f:
                f.write(selected + "\n")
        except OSError as err:
            logger.error("preferred-output write failed: %s", err)
            conf[f"{ROOT}.status"] = f"No se pudo guardar: {err}"
            return

        session_id = _active_session_id()
        if session_id is None:
            conf[f"{ROOT}.status"] = f"{selected} guardado. Reinicia la sesion a mano."
            return

        logger.info("preferred output set to %s; restarting session %s", selected, session_id)
        conf[f"{ROOT}.status"] = f"{selected} guardado. Reiniciando sesion..."
        subprocess.run(["loginctl", "terminate-session", session_id])
