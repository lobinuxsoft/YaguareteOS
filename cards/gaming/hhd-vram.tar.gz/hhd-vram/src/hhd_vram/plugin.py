"""VRAM carveout plugin: lets the user ask the firmware for a different
UMA Frame Buffer size, validated by the kernel (amdgpu's uma/carveout sysfs).
"""

import logging

from hhd.plugins import Context, HHDPlugin, HHDSettings, load_relative_yaml
from hhd.plugins.conf import Config

from .mem import read_int, uma_dir, uma_options

logger = logging.getLogger(__name__)

# UI config paths (section.container.field). "vram" is our own top-level
# section (not in HHD core's sections.yml, falls back to the capitalized
# key, "Vram") -- separate from "ssh" since the two features share nothing.
ROOT = "vram.carveout"


class VramPlugin(HHDPlugin):
    def __init__(self, device: str) -> None:
        self.name = "hhd_vram"
        self.priority = 60
        self.log = "vram"
        self.device = device
        self.emit = None

    def open(self, emit, context: Context) -> None:
        self.emit = emit

    def settings(self) -> HHDSettings:
        sets = load_relative_yaml("settings.yml")
        # The slider's ticks are the firmware's own indices (0, 1, 2, ...),
        # not the raw MiB sizes -- those run up to 5 digits and overlap once
        # there are more than a handful (confirmed on real firmware: 7
        # options, 512..32768). The actual size goes in `status` instead.
        options = uma_options(self.device)
        sets["children"]["level"]["options"] = [o["index"] for o in options]
        sets["children"]["level"]["default"] = read_int(f"{uma_dir(self.device)}/carveout")
        return {"vram": {"carveout": sets}}

    def update(self, conf: Config) -> None:
        options = uma_options(self.device)
        by_index = {o["index"]: o for o in options}
        current = read_int(f"{uma_dir(self.device)}/carveout")

        level = conf.get(f"{ROOT}.level", None)
        selected = by_index.get(level)

        if selected is None:
            conf[f"{ROOT}.status"] = "Sin selección."
        elif selected["index"] == current:
            conf[f"{ROOT}.status"] = f"Actual: {selected['label']}"
        else:
            conf[f"{ROOT}.status"] = f"Vas a asignar: {selected['label']}"

        if not conf.get_action(f"{ROOT}.apply") or not selected:
            return
        if selected["index"] == current:
            return

        try:
            with open(f"{uma_dir(self.device)}/carveout", "w") as f:
                f.write(str(selected["index"]))
        except OSError as err:
            logger.error("carveout write failed: %s", err)
            conf[f"{ROOT}.status"] = f"El firmware rechazo el cambio: {err}"
            return

        logger.info("carveout set to %s (%s); rebooting", selected["index"], selected["label"])
        conf[f"{ROOT}.status"] = f"{selected['label']} pedidos. Reiniciando..."
        import subprocess

        subprocess.run(["reboot"])
