"""hhd-output-select: pick the monitor Gamemode uses, from HHD's own tab.

External Handheld Daemon plugin. Registered via the `hhd.plugins` entry
point; no fork of HHD required.
"""

import logging
from typing import Sequence

from hhd.plugins import HHDPlugin

from .outputs import connected_outputs

logger = logging.getLogger(__name__)


def autodetect(existing: Sequence[HHDPlugin]) -> Sequence[HHDPlugin]:
    """Entry point. Activate only with more than one connected output --
    a single-output machine (the common handheld case) has nothing to
    pick from."""
    if existing:
        return existing

    outputs = connected_outputs()
    if len(outputs) < 2:
        logger.info("Fewer than two connected outputs; hhd-output-select disabled.")
        return []

    from .plugin import OutputSelectPlugin

    logger.info(f"hhd-output-select active for outputs: {outputs}")
    return [OutputSelectPlugin()]
