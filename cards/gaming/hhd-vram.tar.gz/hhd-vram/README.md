# hhd-vram

Handheld Daemon plugin that moves the AMD APU firmware's UMA Frame Buffer
(the fixed RAM carveout reported as "VRAM") to a different size, from HHD's
own TDP tab.

v0.2.0 replaces the original `ttm.pages_limit`/GTT-based approach (v0.1.0,
shipped 2026-06 in `yaguarete_os`, retired 2026-08-21 when Bazzite 44 dropped
HHD) with a simpler, more correct fix: on kernels/platforms that expose it,
`amdgpu` lets the OS ask the firmware to move the actual carveout directly
(`<card>/device/uma/carveout`), validated by the kernel. GTT competes for the
same unified DDR anyway, so moving the real carveout is strictly better where
supported.

Registered via the `hhd.plugins` setuptools entry point -- no fork of HHD
required. Activates only on devices whose firmware answers the ACPI method
that exposes `uma/carveout`; its absence is treated as "this machine can't do
this," not a reason to poke the firmware by hand.

License: MIT.
