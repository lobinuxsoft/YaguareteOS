"""VRAM carveout plugin: lets the user ask the firmware for a different
UMA Frame Buffer size, validated by the kernel (amdgpu's uma/carveout sysfs).
"""

import logging

from hhd.plugins import Context, HHDPlugin, HHDSettings, load_relative_yaml
from hhd.plugins.conf import Config

from .mem import bytes_to_gib, ram_bytes, read_int, read_vram_total, uma_dir, uma_options

logger = logging.getLogger(__name__)

# UI config paths (section.container.field). Co-located in the TDP tab next to
# the other GPU controls; merges with adjustor's "tdp" section when present.
ROOT = "tdp.vram"


class VramPlugin(HHDPlugin):
    def __init__(self, device: str) -> None:
        self.name = "hhd_vram"
        self.priority = 60
        self.log = "vram"
        self.device = device
        self.emit = None

    def open(self, emit, context: Context) -> None:
        self.emit = emit

    def settings(self) -> HHDSettings:
        sets = load_relative_yaml("settings.yml")
        options = uma_options(self.device)
        sets["children"]["mib"]["options"] = [o["mib"] for o in options]
        current = read_int(f"{uma_dir(self.device)}/carveout")
        selected = next((o for o in options if o["index"] == current), None)
        sets["children"]["mib"]["default"] = selected["mib"] if selected else None
        return {"tdp": {"vram": sets}}

    def update(self, conf: Config) -> None:
        total_gib = bytes_to_gib(ram_bytes())
        vram = read_vram_total(self.device)
        conf[f"{ROOT}.info"] = f"UMA {bytes_to_gib(vram):.1f} GiB of {total_gib:.1f} GiB RAM"

        options = uma_options(self.device)
        mib = conf.get(f"{ROOT}.mib", None)
        selected = next((o for o in options if o["mib"] == mib), None) if mib else None
        conf[f"{ROOT}.selected_label"] = selected["label"] if selected else ""

        if not conf.get_action(f"{ROOT}.apply") or not selected:
            return

        current = read_int(f"{uma_dir(self.device)}/carveout")
        if selected["index"] == current:
            conf[f"{ROOT}.status"] = "Already set."
            return

        try:
            with open(f"{uma_dir(self.device)}/carveout", "w") as f:
                f.write(str(selected["index"]))
        except OSError as err:
            logger.error("carveout write failed: %s", err)
            conf[f"{ROOT}.status"] = f"El firmware rechazo el cambio: {err}"
            return

        logger.info("carveout set to %s (%s); rebooting", selected["index"], selected["label"])
        conf[f"{ROOT}.status"] = f"{selected['label']} pedidos. Reiniciando..."
        import subprocess

        subprocess.run(["reboot"])
