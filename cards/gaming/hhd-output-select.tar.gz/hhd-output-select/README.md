# hhd-output-select

Handheld Daemon plugin that lets the user pick which connected monitor
Gamemode's Gamescope session uses, from HHD's own settings tab.

Gamescope only takes a preferred output (`-O`/`--prefer-output`) at startup;
neither Gamescope nor Steam's Big Picture UI expose a way to change it while
running. This plugin writes the chosen connector to
`/etc/yaguarete/gamescope-preferred-output`, which
`cards/gaming/files/yaguarete-gamemode` reads when it builds `gamescope`'s
argument list, then ends the current graphical session so the display
manager starts a fresh one with the new output applied. On a machine whose
default session is Gamemode (the handheld case this plugin targets) that
means landing straight back in Gamemode; on a desktop-style login it drops
back to the login screen, since there is no way to restart Gamescope's
compositor in place.

Activates only when more than one display connector is reported connected
(`/sys/class/drm/*/status`); a single-output machine (the common handheld
case) has nothing to pick from.

Registered via the `hhd.plugins` setuptools entry point -- no fork of HHD
required.

License: MIT.
