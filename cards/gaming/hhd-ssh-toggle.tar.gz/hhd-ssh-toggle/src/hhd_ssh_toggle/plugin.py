"""sshd on/off switch, exposed next to HHD's other system controls."""

import logging
import subprocess

from hhd.plugins import Context, HHDPlugin, HHDSettings, load_relative_yaml
from hhd.plugins.conf import Config

logger = logging.getLogger(__name__)

ROOT = "tdp.ssh"
UNIT = "sshd.service"


def _is_enabled() -> bool:
    out = subprocess.run(
        ["systemctl", "is-enabled", UNIT], capture_output=True, text=True
    )
    return out.stdout.strip() == "enabled"


class SshTogglePlugin(HHDPlugin):
    def __init__(self) -> None:
        self.name = "hhd_ssh_toggle"
        self.priority = 61
        self.log = "ssh"
        self.emit = None

    def open(self, emit, context: Context) -> None:
        self.emit = emit

    def settings(self) -> HHDSettings:
        sets = load_relative_yaml("settings.yml")
        sets["children"]["enabled"]["default"] = _is_enabled()
        return {"tdp": {"ssh": sets}}

    def update(self, conf: Config) -> None:
        want_enabled = conf.get(f"{ROOT}.enabled", None)
        if want_enabled is None:
            return

        is_enabled = _is_enabled()
        if want_enabled == is_enabled:
            return

        action = "enable" if want_enabled else "disable"
        try:
            subprocess.run(
                ["systemctl", action, "--now", UNIT], check=True, capture_output=True, text=True
            )
        except subprocess.CalledProcessError as err:
            logger.error("systemctl %s %s failed: %s", action, UNIT, err.stderr)
            conf[f"{ROOT}.status"] = f"Falló: {err.stderr.strip()}"
            conf[f"{ROOT}.enabled"] = is_enabled
            return

        logger.info("%s %s", action, UNIT)
        conf[f"{ROOT}.status"] = "SSH activo." if want_enabled else "SSH apagado."
