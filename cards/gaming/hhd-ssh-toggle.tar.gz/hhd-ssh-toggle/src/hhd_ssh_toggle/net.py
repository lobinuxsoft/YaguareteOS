"""Local IPv4 addresses and primary user, for display next to the SSH toggle."""

import pwd
import socket


def primary_user() -> str | None:
    """First human login account (UID >= 1000), the handheld's single user.

    hhd.service runs as root, so there is no login user in its own
    environment to read this from.
    """
    candidates = sorted(
        (u for u in pwd.getpwall() if u.pw_uid >= 1000 and u.pw_shell not in ("/usr/sbin/nologin", "/sbin/nologin")),
        key=lambda u: u.pw_uid,
    )
    return candidates[0].pw_name if candidates else None


def primary_ip() -> str | None:
    """The IPv4 address on this host's default route, if any.

    A UDP "connect" picks the outbound-facing interface without sending a
    packet. With two NICs up (wifi + ethernet) this is the one the default
    route would actually use -- showing every address the host owns just
    clutters the panel with addresses that may not even be reachable.
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except OSError:
        return None
