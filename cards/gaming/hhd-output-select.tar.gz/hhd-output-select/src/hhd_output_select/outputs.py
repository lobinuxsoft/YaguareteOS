"""sysfs reads for connected DRM display connectors."""

import glob
import os

_STATUS_GLOB = "/sys/class/drm/*/status"


def connected_outputs() -> list[str]:
    """Connector names (e.g. "DP-1", "HDMI-A-2") reported connected, sorted."""
    outputs = []
    for status_path in sorted(glob.glob(_STATUS_GLOB)):
        try:
            with open(status_path) as f:
                if f.read().strip() != "connected":
                    continue
        except OSError:
            continue
        # .../drm/card0-DP-1/status -> DP-1
        name = os.path.basename(os.path.dirname(status_path))
        name = name.split("-", 1)[1] if "-" in name else name
        outputs.append(name)
    return outputs
