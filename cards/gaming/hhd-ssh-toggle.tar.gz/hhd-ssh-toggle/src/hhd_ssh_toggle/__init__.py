"""hhd-ssh-toggle: toggle sshd on/off from HHD's settings UI.

External Handheld Daemon plugin. Registered via the `hhd.plugins` entry point;
no fork of HHD required.
"""

import logging
import shutil
from typing import Sequence

from hhd.plugins import HHDPlugin

logger = logging.getLogger(__name__)


def autodetect(existing: Sequence[HHDPlugin]) -> Sequence[HHDPlugin]:
    """Entry point. Activate only when systemctl is actually available --
    its absence is the honest signal this is not a systemd system, not a
    reason to shell out blindly."""
    if existing:
        return existing

    if not shutil.which("systemctl"):
        logger.info("No systemctl; hhd-ssh-toggle disabled.")
        return []

    from .plugin import SshTogglePlugin

    return [SshTogglePlugin()]
