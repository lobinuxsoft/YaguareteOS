# hhd-ssh-toggle

Handheld Daemon plugin: toggle `sshd` on/off from HHD's own settings UI.

YaguareteOS ships `sshd` disabled by default on fresh installs/upgrades
(`cards/base/base.yml`, `80-yaguarete-ssh.preset`). Without a keyboard
attached, there is no way to turn it back on from the handheld. This plugin
exposes a single switch next to TDP/RGB that calls `systemctl enable --now`/
`disable --now` on `sshd.service`, reading its current state on open.
